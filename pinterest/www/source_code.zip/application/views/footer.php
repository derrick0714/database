
<div id="footer">
	<div class="footer_container container">
		<p class="text-muted credit"> <center>Powerd by <a href="http://www.dengxu.me">Xu Deng</a> @ 12/2013 </center></p>
	</div>
</div>

	<!-- Bootstrap core JavaScript
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
	<script src="<?=JS?>/bootstrap.min.js"></script>
</body>
</html>