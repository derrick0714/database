<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Search extends CI_Controller {

// in welcome.php->search
	public function key( )
	{

		is_user_login($this);

		//iffriends





}