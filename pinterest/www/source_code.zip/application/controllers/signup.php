<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Signup extends CI_Controller {


	public function index()
	{
		echo "hi";
	}
}

/* End of file Singup.php */
/* Location: ./application/controllers/Singup.php */